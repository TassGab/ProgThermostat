adpter uart-zigbee and zigbee-ble

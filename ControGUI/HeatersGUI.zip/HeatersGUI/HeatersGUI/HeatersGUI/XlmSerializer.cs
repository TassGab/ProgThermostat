﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace XmlSerializer_my
{
    public class XmlSerializer<T>
    {
        public void SerializeToXML(T obj, string filename)
        {
            var xns = new XmlSerializerNamespaces();
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            xns.Add("gtas", "www.github.com");
            TextWriter textWriter = new StreamWriter(filename);
            serializer.Serialize(textWriter, obj, xns);
            textWriter.Close();
        }
        public T DeserializeFromXML(string filename)
        {
            XmlSerializer deserializer = new XmlSerializer(typeof(T));

            TextReader textReader = new StreamReader(filename);
            T obj;
            obj = (T)deserializer.Deserialize(textReader);
            textReader.Close();

            return obj;
        }
    }
}

﻿/*
 * Created by SharpDevelop.
 * User: tasselli
 * Date: 28/10/2017
 * Time: 17:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports;
using System.Timers;

namespace HeatersGUI
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public BindingSource bindingSourceMond = new BindingSource();
		ProTherm PT;
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			string [] SportList=SerialPort.GetPortNames();
			foreach (var element in SportList) {
				Com_cb.Items.Add(element);
			}
			if(Com_cb.Items.Count>0) Com_cb.SelectedIndex=0;
			Uartbaud_cb.SelectedItem="38400";
			PT=new ProTherm(Sport);
			
		}
		void Connect_btClick(object sender, EventArgs e)
		{
			if(Connect_bt.Text=="Connect")
			{
				Sport.BaudRate=int.Parse(Uartbaud_cb.SelectedItem.ToString());
				Sport.PortName=Com_cb.SelectedItem.ToString();
				Sport.NewLine="\n";
				try
				{
					Sport.Open();
					Connect_bt.Text="Disconnect";					
					groupBox1.Enabled=true;
					timer1.Enabled=true;
					
				}
				catch
				{
					MessageBox.Show("Could not open port {0}",Com_cb.SelectedItem.ToString());
					groupBox1.Enabled=false;
					timer1.Enabled=false;
				}
			}
			else
			{
				
				Connect_bt.Text="Connect";
				groupBox1.Enabled=false;
				timer1.Enabled=false;
				Sport.Close();
			}
		}
		void SportDataRx(object sender, SerialDataReceivedEventArgs e)
		{
	
		}
		void SetTime_bt(object sender, EventArgs e)
		{
			time_lb.Text=PT.SetTime();
		}
		void timer1tick(object sender, EventArgs e)
		{
            //if (Sport.BytesToRead>0)
            //{
            //    String answer=Sport.ReadLine();
            //richTextBox1.AppendText(answer+"\n");
            //PT.CmdAnswers(answer);
            //richTextBox1.ScrollToCaret();
            //}
            ReadSP();
		}
        void ReadSP()
        {
            if (Sport.BytesToRead>0)
			{
                String answer=Sport.ReadLine();
			richTextBox1.AppendText(answer+"\n");
            PT.CmdAnswers(answer);
			richTextBox1.ScrollToCaret();
			}
            return;
        }
		void RdStatus_bt(object sender, EventArgs e)
		{
			PT.RdStatus();
		}
		void SetDayEv_bt(object sender, EventArgs e)
		{
			UInt32 quart;
			quart= Convert.ToUInt32(hh_nud.Value*4)+Convert.ToUInt32(min_nud.Value/15);
            MessageBox.Show(Day_cb.SelectedIndex.ToString());
			PT.SetAlarmDay(1, Convert.ToUInt32(evnum_nud.Value), Convert.ToUInt32(quart),en_cb.Checked, onoff_cb.Checked);
		}

        private void SetOnce_bt_Click(object sender, EventArgs e)
        {
            
            UInt32 quart;
			quart= Convert.ToUInt32(dateTimePicker1.Value.Hour*4)+Convert.ToUInt32(Math.Round(dateTimePicker1.Value.Minute/15.0,0));
            PT.SetAlarmOnce(quart, dateTimePicker1.Value.Day, dateTimePicker1.Value.Month, dateTimePicker1.Value.Year, ENonce_cb.Checked, ONOFFonce_cb.Checked);
            
        }

        private void StatSet_bt_Click(object sender, EventArgs e)
        {
            UInt16 _uart=(ushort)Uart_log_cb.SelectedIndex;
            UInt16 _zb = (ushort)ZB_log_cb.SelectedIndex;
            //MessageBox.Show("uART="+_uart);
            UInt16 _mode=(ushort)Mode_cb.SelectedIndex;
            //MessageBox.Show("MODE=" + _mode);
            UInt16 _clockp=(ushort)ClockPer_nud.Value;
            int _Tadj=(int)Timeadj_nud.Value;
            PT.SetStat(_uart, _zb, _mode, _clockp, _Tadj);
        }

        private void StatusRead_bt_Click(object sender, EventArgs e)
        {
            PT.RdStatus();
            TimeoutType to=new TimeoutType(10000);
            bool wait = true;
            while (wait)
            {
                wait = !PT.Status.Updated & !to.Expired;
                this.Update();
                ReadSP();
                System.Threading.Thread.Sleep(100);
            }
            if (PT.Status.Updated)
            {
                Mode_cb.SelectedItem = PT.Status.Mode;
                Uart_log_cb.SelectedItem = PT.Status.UartLev;
                ZB_log_cb.SelectedItem = PT.Status.ZBLev;
                Timeadj_nud.Value = Decimal.Parse(PT.Status.TimeAdj);
                ClockPer_nud.Value = Decimal.Parse(PT.Status.ClockPer);
                ProgTermTime_lb.Text = PT.Status.RemTime;
                NextEv_tb.Text = PT.Status.NextEv;
            }

        }
	}
public class TimeoutType
    {
        public bool Expired = false;
        System.Timers.Timer myTimer = new System.Timers.Timer();
        public TimeoutType(double myInterval)
        {
            myTimer.Interval = myInterval;
            myTimer.AutoReset = false;
            myTimer.Elapsed += OnTimerElapsed;
            myTimer.Start();
        }
        public void OnTimerElapsed(object sender, ElapsedEventArgs eventArgs)
        {
            myTimer.Stop();
            Expired = true;
        }
        public void Stop()
        { myTimer.Stop(); }

    }
 //Class for Daily schedule
	public class DaySched{
		String Time;
		bool Enable;
		bool SwState;
		public DaySched(String _time, bool _en, bool _st)
		{
			Time=_time;
			Enable=_en;
			SwState=_st;
		}
	}
    
//Class for ProTherm communication
	public class ProTherm
	{
        public struct Status_st
        {
            public String HeaterSt;
            public String Mode;
            public String UartLev;
            public String ZBLev;
            public String ClockPer;
            public String TimeAdj;
            public String NextEv;
            public String RemTime;
            public bool Updated;
        }
        public Status_st Status;
		private SerialPort SP;
		public ProTherm(SerialPort _SP)
		{
			SP=_SP;
            Status.Updated = false;
		}
	    private void WriteCmd(String s)
        {
            SP.Write(s + '\n');
            return;
        }
		public string SetTime()
		{
			String timenow=DateTime.Now.ToString();
			//MessageBox.Show(timenow);
			string[] dates=timenow.Split(' ');
			int day=int.Parse(dates[0].Split('/')[0]);
			int mo=int.Parse(dates[0].Split('/')[1]);
			int yy=int.Parse(dates[0].Split('/')[2]);
			int hh=int.Parse(dates[1].Split(':')[0]);
			int mm=int.Parse(dates[1].Split(':')[1]);
			int ss=int.Parse(dates[1].Split(':')[2]);
			string cmd="#1,"+hh.ToString()+","+mm.ToString()+","+ss.ToString()
				+","+day.ToString()+","+mo.ToString()+","+(yy-2000).ToString()+".";
			//MessageBox.Show(cmd);
			WriteCmd(cmd);
			return timenow;
		}
		public void RdStatus()
		{
			string cmd="#4.";
            Status.Updated = false;
			//MessageBox.Show(cmd);
			WriteCmd(cmd);
		}
		public void SetAlarmDay(UInt16 _dow, UInt32 _ev, UInt32 _q, bool _en, bool _state)
		{
            string _enstr = "";
            string _ststr = "";
            if (_en) _enstr = "1"; else _enstr = "0";
            if (_state) _ststr = "1"; else _ststr = "0";
			string cmd="#2,"+_dow+","+_ev.ToString()+","+_q.ToString()+","+_enstr+","+_ststr+",0.";
			MessageBox.Show(cmd);
			WriteCmd(cmd);
			
		}
        public void SetAlarmOnce(UInt32 _q, int _dd, int _mo, int _yy, bool _en, bool _state)
        {
            //#8,quarter,gg,mo,yy,en,on/off.
            string _enstr = "";
            string _ststr = "";
            if (_en) _enstr = "1"; else _enstr = "0";
            if (_state) _ststr = "1"; else _ststr = "0";
            string cmd = "#8," + _q.ToString() + "," + _dd.ToString() + "," + _mo.ToString() + "," + _yy.ToString() + "," + _enstr + "," + _ststr + ".";
            MessageBox.Show(cmd);
            WriteCmd(cmd);
        }
        public void SetStat(UInt16 _uart, UInt16 _zb, UInt16 _mode, UInt16 _clockp, int _Tadj)
        {
            //format: #5,Uartlev,ZBlev,Mode,ClockPer,TimeAdj.
           string cmd = "#5," + _uart.ToString() + "," + _zb.ToString() + "," + _mode.ToString() + "," + _clockp.ToString() + "," + _Tadj.ToString()+ ".";
            MessageBox.Show(cmd);
            WriteCmd(cmd);
        }
        public String CmdAnswers(String instr)
        {
            int cmd;
            if(instr.StartsWith("#"))
            {
                //a command answer is arrived
                instr = instr.TrimStart('#');
                int.TryParse(instr.Split('>')[0],out cmd);
                //String[] _s=instr1.Split(':');
                //String instr="";
                //for (int idx = 1; idx < _s.Length;idx++ )
                //{
                //    instr += _s[idx];
                //}
                instr = instr.Split('>')[1];
                switch (cmd)
                {
                    case 1:
                        if (instr == "Num. of field is wrong") MessageBox.Show("Num. of field is wrong", "Error");
                        break;
                    case 2:
                        if (instr == "Num. of field is wrong") MessageBox.Show("Num. of field is wrong", "Error");
                        break;
                    case 4:
                        if (instr.StartsWith("Status"))
                        {
                            Status = ParseStatus(instr);                            
                        }
                        if (instr.StartsWith("Next"))
                        {
                            Status.NextEv = instr.Split('=')[1];
                        }
                        if (instr.StartsWith("Time"))
                        {
                            Status.RemTime = instr.Split('=')[1];
                        }
                        if (instr.StartsWith("OK"))
                        {
                            Status.Updated = true;
                        }
                        if (instr == "Num. of field is wrong") MessageBox.Show("Num. of field is wrong", "Error");
                        break;                        
                    default:
                        break;
                }
                
                return instr;     
            }
            return null;
        }
       
        public Status_st ParseStatus(String s)
        {
            //Status=[Heater=OFF,Mode=Daily,UART=Verbose,ZB=Info,ClockPer=5,TimeAdj=-35]
            Status_st status = new Status_st();
            String[] _status = s.Split('=',',');
            status.HeaterSt = _status[2];
            status.Mode = _status[4];
            status.UartLev = _status[6];
            status.ZBLev= _status[8];
            status.ClockPer= _status[10];
            status.TimeAdj = _status[12].TrimEnd(']');
            //status.Updated = true;
            return status;
        }
	}

}

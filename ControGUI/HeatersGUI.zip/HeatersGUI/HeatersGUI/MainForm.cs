﻿/*
 * Created by SharpDevelop.
 * User: tasselli
 * Date: 28/10/2017
 * Time: 17:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports;
using System.Timers;
using HeatersScheduler;
using System.ComponentModel;

namespace HeatersGUI
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public BindingSource bindingSourceMond = new BindingSource();
		ProTherm PT;
		public BindingList<DaySched> blist=new BindingList<DaySched>();
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			string [] SportList=SerialPort.GetPortNames();
			foreach (var element in SportList) {
				Com_cb.Items.Add(element);
			}
			if(Com_cb.Items.Count>0) Com_cb.SelectedIndex=0;
			Uartbaud_cb.SelectedItem="38400";
			PT=new ProTherm(Sport);
			
		}
		void Connect_btClick(object sender, EventArgs e)
		{
			if(Connect_bt.Text=="Connect")
			{
				Sport.BaudRate=int.Parse(Uartbaud_cb.SelectedItem.ToString());
				Sport.PortName=Com_cb.SelectedItem.ToString();
				Sport.NewLine="\n";
				try
				{
					Sport.Open();
					Connect_bt.Text="Disconnect";					
					groupBox1.Enabled=true;
					timer1.Enabled=true;
					DataGridDefaultFill();
					DOW_cb.SelectedItem="Monday";
				}
				catch
				{
					MessageBox.Show("Could not open port {0}",Com_cb.SelectedItem.ToString());
					groupBox1.Enabled=false;
					timer1.Enabled=false;
				}
			}
			else
			{
				
				Connect_bt.Text="Connect";
				groupBox1.Enabled=false;
				timer1.Enabled=false;
				Sport.Close();
			}
		}
		
		void SetTime_bt(object sender, EventArgs e)
		{
			time_lb.Text=PT.SetTime();
		}
		void timer1tick(object sender, EventArgs e)
		{
            ReadSP();
            GUIcontentUpdate();
		}
        void ReadSP()
        {
            if (Sport.BytesToRead>0)
			{
                String answer=Sport.ReadLine();
			richTextBox1.AppendText(answer+"\n");
            PT.CmdAnswers(answer);
			richTextBox1.ScrollToCaret();
			}
            return;
        }
        void GUIcontentUpdate()
        {
        	if(PT.Status.TimeStateRead) 
        	{
        		time_lb.Text=PT.Status.RemTime;
        		HState_lb.Text=PT.Status.HeaterSt;
        	 	PT.Status.TimeStateRead = false;
        	}
        }
		void RdStatus_bt(object sender, EventArgs e)
		{
            PT.EepromDefault();
		}
		
        private ushort DayStrToNum(String dow)
        {
            ushort downum = 0;
            if (dow == "Sunday") downum = 1;
            else if (dow == "Monday") downum = 2;
            else if (dow == "Tuesday") downum = 3;
            else if (dow == "Wednesday") downum = 4;
            else if (dow == "Thursday") downum = 5;
            else if (dow == "Friday") downum = 6;
            else if (dow == "Saturday") downum = 7;
            else downum = 0;
            return downum;
        }
        private void SetOnce_bt_Click(object sender, EventArgs e)
        {
            
            UInt32 quart;
			quart= Convert.ToUInt32(dateTimePicker1.Value.Hour*4)+Convert.ToUInt32(Math.Round(dateTimePicker1.Value.Minute/15.0,0));
            PT.SetAlarmOnce(quart, dateTimePicker1.Value.Day, dateTimePicker1.Value.Month, dateTimePicker1.Value.Year-2000, ENonce_cb.Checked, ONOFFonce_cb.Checked);
            
        }

        private void StatSet_bt_Click(object sender, EventArgs e)
        {
            UInt16 _uart=(ushort)Uart_log_cb.SelectedIndex;
            UInt16 _zb = (ushort)ZB_log_cb.SelectedIndex;
            //MessageBox.Show("uART="+_uart);
            UInt16 _mode=(ushort)Mode_cb.SelectedIndex;
            //MessageBox.Show("MODE=" + _mode);
            UInt16 _clockp=(ushort)ClockPer_nud.Value;
            int _Tadj=(int)Timeadj_nud.Value;
            PT.SetStat(_uart, _zb, _mode, _clockp, _Tadj);
        }

        private void StatusRead_bt_Click(object sender, EventArgs e)
        {
            PT.RdStatus();
            TimeoutType to=new TimeoutType(10000);
            bool wait = true;
            while (wait)
            {
                wait = !PT.Status.Updated & !to.Expired;
                this.Update();
                ReadSP();
                System.Threading.Thread.Sleep(100);
            }
            if (PT.Status.Updated)
            {
                Mode_cb.SelectedItem = PT.Status.Mode;
                Uart_log_cb.SelectedItem = PT.Status.UartLev;
                ZB_log_cb.SelectedItem = PT.Status.ZBLev;
                Timeadj_nud.Value = Decimal.Parse(PT.Status.TimeAdj);
                ClockPer_nud.Value = Decimal.Parse(PT.Status.ClockPer);
                ProgTermTime_lb.Text = PT.Status.RemTime;
                NextEv_tb.Text = PT.Status.NextEv;
            }

        }

        private void ManON_bt_Click(object sender, EventArgs e)
        {
            PT.ManSW(true);
        }

        private void ManOFF_bt_Click(object sender, EventArgs e)
        {
            PT.ManSW(false);
        }
		
		void DataGridDefaultFill()
		{
			bindingSourceMond.Add(new DaySched(0,"8:30",true,true));
			bindingSourceMond.Add(new DaySched(1,"9:30",true,false));
			bindingSourceMond.Add(new DaySched(2,"9:30",false,false));
			bindingSourceMond.Add(new DaySched(3,"9:30",false,false));
			bindingSourceMond.Add(new DaySched(4,"9:30",false,false));
			bindingSourceMond.Add(new DaySched(5,"9:30",false,false));
			bindingSource1.DataSource=bindingSourceMond;
			
            // Put the cells in edit mode when user enters them.
            //dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
			dataGridView1.DataSource=bindingSource1;
			dataGridView1.AutoGenerateColumns=true;	
			dataGridView1.AutoSizeRowsMode =
            DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
			dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
             
		// Set the DataGridView control's border.
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;
			
			dataGridView1.EditMode=DataGridViewEditMode.EditProgrammatically;
			//dataGridView1.Columns[2].
			dataGridView1.Show();
		}
		void DataGridView1DoubleClick(object sender, EventArgs e)
		{
			Form1 FormInput=new Form1();
			FormInput.ShowDialog();
			int evnum=dataGridView1.SelectedCells[0].RowIndex;
			
			FormInput.ds.EvNum=Convert.ToUInt16(evnum);
			bindingSourceMond[evnum]=FormInput.ds;
			dataGridView1.Refresh();
		}
		void ReadSche_btClick(object sender, EventArgs e)
		{
			for (ushort _evnum=0;_evnum<6;_evnum++)
			{
				
				PT.ReadAlarm(DayStrToNum(DOW_cb.SelectedItem.ToString()),_evnum);
				TimeoutType to=new TimeoutType(5000);
	            bool wait = true;
	            while (wait)
	            {
	                wait = !PT.DaySchedEv.Updated & !to.Expired;
	                this.Update();
	                ReadSP();
	                System.Threading.Thread.Sleep(100);
	            }
	            if (PT.DaySchedEv.Updated)
	            {
	            	PT.DaySchedEv.DS.EvNum=_evnum;
	                bindingSourceMond[_evnum]=PT.DaySchedEv.DS;
	                dataGridView1.Refresh();
	                PT.DaySchedEv.Updated=false;
	            }
			}
			
		}
		void SetDayAl_btClick(object sender, EventArgs e)
		{
			int evnum=dataGridView1.SelectedCells[0].RowIndex;
			String _t=dataGridView1.Rows[evnum].Cells[1].Value.ToString();
			uint _q=PT.TimeToQuarter(_t);
			bool _en;
			bool _sw;
			if(bool.Parse(dataGridView1.Rows[evnum].Cells[2].Value.ToString())) _en=true; else _en=false;
			if(bool.Parse(dataGridView1.Rows[evnum].Cells[3].Value.ToString())) _sw=true; else _sw=false;
			PT.SetAlarmDay(DayStrToNum(DOW_cb.SelectedItem.ToString()),Convert.ToUInt16(evnum),_q,_en,_sw);
		}
		void Set_btClick(object sender, EventArgs e)
		{
			ushort _mode=0;
			if(Man_rb.Checked) _mode=0;
			else if (Daily_rb.Checked) _mode=1;
			else if (Once_rb.Checked) _mode=2;
			else if (Out_rb.Checked) _mode=3;
			PT.ModeSel(_mode);
		}
	}
public class TimeoutType
    {
        public bool Expired = false;
        System.Timers.Timer myTimer = new System.Timers.Timer();
        public TimeoutType(double myInterval)
        {
            myTimer.Interval = myInterval;
            myTimer.AutoReset = false;
            myTimer.Elapsed += OnTimerElapsed;
            myTimer.Start();
        }
        public void OnTimerElapsed(object sender, ElapsedEventArgs eventArgs)
        {
            myTimer.Stop();
            Expired = true;
        }
        public void Stop()
        { myTimer.Stop(); }

    }
 
    

}

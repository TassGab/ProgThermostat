﻿/*
 * Created by SharpDevelop.
 * User: tasselli
 * Date: 11/11/2017
 * Time: 16:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO.Ports;

namespace HeatersScheduler
{
	/// <summary>
	/// Description of Class1.
	/// </summary>

	//Class for Daily schedule
	public class DaySched{
		public ushort EvNum{get;set;}
		public String Time{get;set;}
		public bool Enable{get;set;}
		public bool SwState{get;set;}
		public DaySched(ushort _evnum, String _time, bool _en, bool _st)
		{
			EvNum=_evnum;
			Time=_time;
			Enable=_en;
			SwState=_st;
		}
	}
	//Class for ProTherm communication
	public class ProTherm
	{
        public struct Status_st
        {
            public String HeaterSt;
            public String Mode;
            public String UartLev;
            public String ZBLev;
            public String ClockPer;
            public String TimeAdj;
            public String NextEv;
            public String RemTime;
            public bool Updated;
        }
        public Status_st Status;
        public String Message="";
		private SerialPort SP;
		public ProTherm(SerialPort _SP)
		{
			SP=_SP;
            Status.Updated = false;
		}
	    private void WriteCmd(String s)
        {
            SP.Write(s + '\n');
            return;
        }
		public string SetTime()
		{
			String timenow=DateTime.Now.ToString();
			//MessageBox.Show(timenow);
			string[] dates=timenow.Split(' ');
			int day=int.Parse(dates[0].Split('/')[0]);
			int mo=int.Parse(dates[0].Split('/')[1]);
			int yy=int.Parse(dates[0].Split('/')[2]);
			int hh=int.Parse(dates[1].Split(':')[0]);
			int mm=int.Parse(dates[1].Split(':')[1]);
			int ss=int.Parse(dates[1].Split(':')[2]);
			string cmd="#1,"+hh.ToString()+","+mm.ToString()+","+ss.ToString()
				+","+day.ToString()+","+mo.ToString()+","+(yy-2000).ToString()+".";
			Message=cmd;
			WriteCmd(cmd);
			return timenow;
		}
		public void RdStatus()
		{
			string cmd="#4.";
            Status.Updated = false;
			Message=cmd;
			WriteCmd(cmd);
		}
        public void EepromDefault()
        {
            string cmd = "#10,1.";
            Status.Updated = false;
            Message=cmd;
            WriteCmd(cmd);
        }
		public void SetAlarmDay(ushort _dow, UInt32 _ev, UInt32 _q, bool _en, bool _state)
		{
            string _enstr = "";
            string _ststr = "";
            if (_en) _enstr = "1"; else _enstr = "0";
            if (_state) _ststr = "1"; else _ststr = "0";
            string cmd = "#2," +_dow + "," + _ev.ToString() + "," + _q.ToString() + "," + _enstr + "," + _ststr + ",0.";
			Message=cmd;
			WriteCmd(cmd);
			
		}
        public void SetAlarmOnce(UInt32 _q, int _dd, int _mo, int _yy, bool _en, bool _state)
        {
            //#8,quarter,gg,mo,yy,en,on/off.
            string _enstr = "";
            string _ststr = "";
            if (_en) _enstr = "1"; else _enstr = "0";
            if (_state) _ststr = "1"; else _ststr = "0";
            string cmd = "#8," + _q.ToString() + "," + _dd.ToString() + "," + _mo.ToString() + "," + _yy.ToString() + "," + _enstr + "," + _ststr + ".";
            Message=cmd;
            WriteCmd(cmd);
        }
        public void SetStat(UInt16 _uart, UInt16 _zb, UInt16 _mode, UInt16 _clockp, int _Tadj)
        {
            //format: #5,Uartlev,ZBlev,Mode,ClockPer,TimeAdj.
           string cmd = "#5," + _uart.ToString() + "," + _zb.ToString() + "," + _mode.ToString() + "," + _clockp.ToString() + "," + _Tadj.ToString()+ ".";
            Message=cmd;
            WriteCmd(cmd);
        }
        public void ManSW(bool state)
        {
            String SwSt="";
            if(state) SwSt="1"; else SwSt="0";
            String cmd = "#7," + SwSt+".";
            Message=cmd;
            WriteCmd(cmd);
        }
        public String CmdAnswers(String instr)
        {
            int cmd;
            if (instr.StartsWith("#"))
            {
                //a command answer is arrived
                instr = instr.TrimStart('#');
                int.TryParse(instr.Split('>')[0], out cmd);
                //String[] _s=instr1.Split(':');
                //String instr="";
                //for (int idx = 1; idx < _s.Length;idx++ )
                //{
                //    instr += _s[idx];
                //}
                try
                {
                    instr = instr.Split('>')[1];
                    switch (cmd)
                    {
                        case 1:
                            if (instr == "Num. of field is wrong") Message="Num. of field is wrong";
                            break;
                        case 2:
                            if (instr == "Num. of field is wrong") Message="Num. of field is wrong";
                            break;
                        case 4:
                            if (instr.StartsWith("Status"))
                            {
                                Status = ParseStatus(instr);
                            }
                            if (instr.StartsWith("Next"))
                            {
                                Status.NextEv = instr.Split('=')[1];
                            }
                            if (instr.StartsWith("Time"))
                            {
                                Status.RemTime = instr.Split('=')[1];
                            }
                            if (instr.StartsWith("OK"))
                            {
                                Status.Updated = true;
                            }
                            if (instr == "Num. of field is wrong") Message="Num. of field is wrong";
                            break;
                        case 10:
                            if (instr == "Num. of field is wrong") Message="Num. of field is wrong";
                            break;
                        default:
                            break;
                    }
                    if (instr.StartsWith("T>")) //Time print
                    {
                        Status.RemTime = instr.Split('>')[1];
                    }
                    if (instr.StartsWith("A>")) //Time print
                    {
                        Status.HeaterSt = instr.Split('>')[1];
                        Status.Updated = true;
                    }

                    return instr;
                }                
            
                catch{}//MessageBox.Show("Format error"); }
            }
            return null;
        }
       
        public Status_st ParseStatus(String s)
        {
            //Status=[Heater=OFF,Mode=Daily,UART=Verbose,ZB=Info,ClockPer=5,TimeAdj=-35]
            Status_st status = new Status_st();
            String[] _status = s.Split('=',',');
            status.HeaterSt = _status[2];
            status.Mode = _status[4];
            status.UartLev = _status[6];
            status.ZBLev= _status[8];
            status.ClockPer= _status[10];
            status.TimeAdj = _status[12].TrimEnd(']');
            //status.Updated = true;
            return status;
        }
	}

}

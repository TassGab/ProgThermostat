﻿/*
 * Created by SharpDevelop.
 * User: tasselli
 * Date: 28/10/2017
 * Time: 17:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace HeatersGUI
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.ComboBox Uartbaud_cb;
		private System.Windows.Forms.Button Connect_bt;
		private System.Windows.Forms.ComboBox Com_cb;
		private System.IO.Ports.SerialPort Sport;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Button EEPROMdefault_bt;
		private System.Windows.Forms.TabPage tabPage10;
		private System.Windows.Forms.Label Satus_lb;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Button OOOset_bt;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.NumericUpDown OooHurs_nud;
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.RemTime_lb = new System.Windows.Forms.Label();
			this.HState_lb = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.now_bt = new System.Windows.Forms.Button();
			this.timeset_tb = new System.Windows.Forms.TextBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.OOOset_bt = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.OooHurs_nud = new System.Windows.Forms.NumericUpDown();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.Set_bt = new System.Windows.Forms.Button();
			this.Out_rb = new System.Windows.Forms.RadioButton();
			this.Once_rb = new System.Windows.Forms.RadioButton();
			this.Daily_rb = new System.Windows.Forms.RadioButton();
			this.Man_rb = new System.Windows.Forms.RadioButton();
			this.ManOFF_bt = new System.Windows.Forms.Button();
			this.ManON_bt = new System.Windows.Forms.Button();
			this.EEPROMdefault_bt = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.Uartbaud_cb = new System.Windows.Forms.ComboBox();
			this.Connect_bt = new System.Windows.Forms.Button();
			this.Com_cb = new System.Windows.Forms.ComboBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.Copyto_cb = new System.Windows.Forms.ComboBox();
			this.CopyDay_bt = new System.Windows.Forms.Button();
			this.SetDayAl_bt = new System.Windows.Forms.Button();
			this.ReadSche_bt = new System.Windows.Forms.Button();
			this.DOW_cb = new System.Windows.Forms.ComboBox();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.tabPage10 = new System.Windows.Forms.TabPage();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.StatusRead_bt = new System.Windows.Forms.Button();
			this.NextEv_tb = new System.Windows.Forms.TextBox();
			this.ProgTermTime_lb = new System.Windows.Forms.Label();
			this.Satus_lb = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.Mode_cb = new System.Windows.Forms.ComboBox();
			this.StatSet_bt = new System.Windows.Forms.Button();
			this.label7 = new System.Windows.Forms.Label();
			this.Uart_log_cb = new System.Windows.Forms.ComboBox();
			this.ClockPer_nud = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.ZB_log_cb = new System.Windows.Forms.ComboBox();
			this.Timeadj_nud = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.tabPage11 = new System.Windows.Forms.TabPage();
			this.ONOFFonce_cb = new System.Windows.Forms.CheckBox();
			this.ENonce_cb = new System.Windows.Forms.CheckBox();
			this.SetOnce_bt = new System.Windows.Forms.Button();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.Sport = new System.IO.Ports.SerialPort(this.components);
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
			this.today_tb = new System.Windows.Forms.Button();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.OooHurs_nud)).BeginInit();
			this.groupBox2.SuspendLayout();
			this.tabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.tabPage10.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.ClockPer_nud)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.Timeadj_nud)).BeginInit();
			this.tabPage11.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage10);
			this.tabControl1.Controls.Add(this.tabPage11);
			this.tabControl1.Location = new System.Drawing.Point(12, 12);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(410, 305);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.RemTime_lb);
			this.tabPage1.Controls.Add(this.HState_lb);
			this.tabPage1.Controls.Add(this.groupBox1);
			this.tabPage1.Controls.Add(this.Uartbaud_cb);
			this.tabPage1.Controls.Add(this.Connect_bt);
			this.tabPage1.Controls.Add(this.Com_cb);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(402, 279);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Setup";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// RemTime_lb
			// 
			this.RemTime_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.RemTime_lb.Location = new System.Drawing.Point(139, 32);
			this.RemTime_lb.Name = "RemTime_lb";
			this.RemTime_lb.Size = new System.Drawing.Size(140, 36);
			this.RemTime_lb.TabIndex = 5;
			this.RemTime_lb.Text = "0:0:0";
			// 
			// HState_lb
			// 
			this.HState_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HState_lb.Location = new System.Drawing.Point(305, 18);
			this.HState_lb.Name = "HState_lb";
			this.HState_lb.Size = new System.Drawing.Size(91, 36);
			this.HState_lb.TabIndex = 4;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.now_bt);
			this.groupBox1.Controls.Add(this.timeset_tb);
			this.groupBox1.Controls.Add(this.groupBox4);
			this.groupBox1.Controls.Add(this.groupBox2);
			this.groupBox1.Controls.Add(this.ManOFF_bt);
			this.groupBox1.Controls.Add(this.ManON_bt);
			this.groupBox1.Controls.Add(this.EEPROMdefault_bt);
			this.groupBox1.Controls.Add(this.button1);
			this.groupBox1.Enabled = false;
			this.groupBox1.Location = new System.Drawing.Point(6, 71);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(390, 204);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Commands";
			// 
			// now_bt
			// 
			this.now_bt.Location = new System.Drawing.Point(219, 21);
			this.now_bt.Name = "now_bt";
			this.now_bt.Size = new System.Drawing.Size(43, 23);
			this.now_bt.TabIndex = 8;
			this.now_bt.Text = "Now";
			this.now_bt.UseVisualStyleBackColor = true;
			this.now_bt.Click += new System.EventHandler(this.Now_btClick);
			// 
			// timeset_tb
			// 
			this.timeset_tb.Location = new System.Drawing.Point(88, 23);
			this.timeset_tb.Name = "timeset_tb";
			this.timeset_tb.Size = new System.Drawing.Size(125, 20);
			this.timeset_tb.TabIndex = 7;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.OOOset_bt);
			this.groupBox4.Controls.Add(this.label1);
			this.groupBox4.Controls.Add(this.OooHurs_nud);
			this.groupBox4.Enabled = false;
			this.groupBox4.Location = new System.Drawing.Point(7, 151);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(200, 47);
			this.groupBox4.TabIndex = 6;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Out of Home";
			// 
			// OOOset_bt
			// 
			this.OOOset_bt.Location = new System.Drawing.Point(113, 18);
			this.OOOset_bt.Name = "OOOset_bt";
			this.OOOset_bt.Size = new System.Drawing.Size(75, 23);
			this.OOOset_bt.TabIndex = 2;
			this.OOOset_bt.Text = "Apply";
			this.OOOset_bt.UseVisualStyleBackColor = true;
			this.OOOset_bt.Click += new System.EventHandler(this.OOOset_btClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(6, 19);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(39, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Hours";
			// 
			// OooHurs_nud
			// 
			this.OooHurs_nud.Location = new System.Drawing.Point(51, 19);
			this.OooHurs_nud.Maximum = new decimal(new int[] {
			10,
			0,
			0,
			0});
			this.OooHurs_nud.Name = "OooHurs_nud";
			this.OooHurs_nud.Size = new System.Drawing.Size(53, 20);
			this.OooHurs_nud.TabIndex = 0;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.Set_bt);
			this.groupBox2.Controls.Add(this.Out_rb);
			this.groupBox2.Controls.Add(this.Once_rb);
			this.groupBox2.Controls.Add(this.Daily_rb);
			this.groupBox2.Controls.Add(this.Man_rb);
			this.groupBox2.Enabled = false;
			this.groupBox2.Location = new System.Drawing.Point(7, 79);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(342, 63);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Mode";
			// 
			// Set_bt
			// 
			this.Set_bt.Location = new System.Drawing.Point(261, 20);
			this.Set_bt.Name = "Set_bt";
			this.Set_bt.Size = new System.Drawing.Size(75, 23);
			this.Set_bt.TabIndex = 4;
			this.Set_bt.Text = "Set";
			this.Set_bt.UseVisualStyleBackColor = true;
			this.Set_bt.Click += new System.EventHandler(this.Set_btClick);
			// 
			// Out_rb
			// 
			this.Out_rb.Location = new System.Drawing.Point(183, 19);
			this.Out_rb.Name = "Out_rb";
			this.Out_rb.Size = new System.Drawing.Size(104, 24);
			this.Out_rb.TabIndex = 3;
			this.Out_rb.TabStop = true;
			this.Out_rb.Text = "Out";
			this.Out_rb.UseVisualStyleBackColor = true;
			// 
			// Once_rb
			// 
			this.Once_rb.Location = new System.Drawing.Point(126, 19);
			this.Once_rb.Name = "Once_rb";
			this.Once_rb.Size = new System.Drawing.Size(104, 24);
			this.Once_rb.TabIndex = 2;
			this.Once_rb.TabStop = true;
			this.Once_rb.Text = "Once";
			this.Once_rb.UseVisualStyleBackColor = true;
			// 
			// Daily_rb
			// 
			this.Daily_rb.Location = new System.Drawing.Point(73, 19);
			this.Daily_rb.Name = "Daily_rb";
			this.Daily_rb.Size = new System.Drawing.Size(104, 24);
			this.Daily_rb.TabIndex = 1;
			this.Daily_rb.TabStop = true;
			this.Daily_rb.Text = "Daily";
			this.Daily_rb.UseVisualStyleBackColor = true;
			// 
			// Man_rb
			// 
			this.Man_rb.Location = new System.Drawing.Point(6, 19);
			this.Man_rb.Name = "Man_rb";
			this.Man_rb.Size = new System.Drawing.Size(104, 24);
			this.Man_rb.TabIndex = 0;
			this.Man_rb.TabStop = true;
			this.Man_rb.Text = "Manual";
			this.Man_rb.UseVisualStyleBackColor = true;
			// 
			// ManOFF_bt
			// 
			this.ManOFF_bt.Location = new System.Drawing.Point(281, 50);
			this.ManOFF_bt.Name = "ManOFF_bt";
			this.ManOFF_bt.Size = new System.Drawing.Size(68, 23);
			this.ManOFF_bt.TabIndex = 4;
			this.ManOFF_bt.Text = "OFF";
			this.ManOFF_bt.UseVisualStyleBackColor = true;
			this.ManOFF_bt.Click += new System.EventHandler(this.ManOFF_bt_Click);
			// 
			// ManON_bt
			// 
			this.ManON_bt.Location = new System.Drawing.Point(281, 21);
			this.ManON_bt.Name = "ManON_bt";
			this.ManON_bt.Size = new System.Drawing.Size(68, 22);
			this.ManON_bt.TabIndex = 3;
			this.ManON_bt.Text = "ON";
			this.ManON_bt.UseVisualStyleBackColor = true;
			this.ManON_bt.Click += new System.EventHandler(this.ManON_bt_Click);
			// 
			// EEPROMdefault_bt
			// 
			this.EEPROMdefault_bt.Location = new System.Drawing.Point(7, 50);
			this.EEPROMdefault_bt.Name = "EEPROMdefault_bt";
			this.EEPROMdefault_bt.Size = new System.Drawing.Size(75, 23);
			this.EEPROMdefault_bt.TabIndex = 2;
			this.EEPROMdefault_bt.Text = "Default EEPROM";
			this.EEPROMdefault_bt.UseVisualStyleBackColor = true;
			this.EEPROMdefault_bt.Click += new System.EventHandler(this.RdStatus_bt);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(7, 20);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 0;
			this.button1.Text = "Set Time";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.SetTime_bt);
			// 
			// Uartbaud_cb
			// 
			this.Uartbaud_cb.FormattingEnabled = true;
			this.Uartbaud_cb.Items.AddRange(new object[] {
			"115200",
			"38400",
			"9600"});
			this.Uartbaud_cb.Location = new System.Drawing.Point(6, 33);
			this.Uartbaud_cb.Name = "Uartbaud_cb";
			this.Uartbaud_cb.Size = new System.Drawing.Size(88, 21);
			this.Uartbaud_cb.TabIndex = 2;
			// 
			// Connect_bt
			// 
			this.Connect_bt.Location = new System.Drawing.Point(101, 6);
			this.Connect_bt.Name = "Connect_bt";
			this.Connect_bt.Size = new System.Drawing.Size(75, 23);
			this.Connect_bt.TabIndex = 1;
			this.Connect_bt.Text = "Connect";
			this.Connect_bt.UseVisualStyleBackColor = true;
			this.Connect_bt.Click += new System.EventHandler(this.Connect_btClick);
			// 
			// Com_cb
			// 
			this.Com_cb.FormattingEnabled = true;
			this.Com_cb.Location = new System.Drawing.Point(6, 6);
			this.Com_cb.Name = "Com_cb";
			this.Com_cb.Size = new System.Drawing.Size(88, 21);
			this.Com_cb.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.today_tb);
			this.tabPage2.Controls.Add(this.Copyto_cb);
			this.tabPage2.Controls.Add(this.CopyDay_bt);
			this.tabPage2.Controls.Add(this.SetDayAl_bt);
			this.tabPage2.Controls.Add(this.ReadSche_bt);
			this.tabPage2.Controls.Add(this.DOW_cb);
			this.tabPage2.Controls.Add(this.dataGridView1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(402, 279);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Scheduler";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// Copyto_cb
			// 
			this.Copyto_cb.FormattingEnabled = true;
			this.Copyto_cb.Items.AddRange(new object[] {
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday",
			"Sunday"});
			this.Copyto_cb.Location = new System.Drawing.Point(317, 222);
			this.Copyto_cb.Name = "Copyto_cb";
			this.Copyto_cb.Size = new System.Drawing.Size(79, 21);
			this.Copyto_cb.TabIndex = 17;
			// 
			// CopyDay_bt
			// 
			this.CopyDay_bt.Location = new System.Drawing.Point(236, 220);
			this.CopyDay_bt.Name = "CopyDay_bt";
			this.CopyDay_bt.Size = new System.Drawing.Size(75, 23);
			this.CopyDay_bt.TabIndex = 16;
			this.CopyDay_bt.Text = "Copy to ";
			this.CopyDay_bt.UseVisualStyleBackColor = true;
			// 
			// SetDayAl_bt
			// 
			this.SetDayAl_bt.Location = new System.Drawing.Point(87, 220);
			this.SetDayAl_bt.Name = "SetDayAl_bt";
			this.SetDayAl_bt.Size = new System.Drawing.Size(75, 23);
			this.SetDayAl_bt.TabIndex = 15;
			this.SetDayAl_bt.Text = "Write Sched";
			this.SetDayAl_bt.UseVisualStyleBackColor = true;
			this.SetDayAl_bt.Click += new System.EventHandler(this.SetDayAl_btClick);
			// 
			// ReadSche_bt
			// 
			this.ReadSche_bt.Location = new System.Drawing.Point(6, 220);
			this.ReadSche_bt.Name = "ReadSche_bt";
			this.ReadSche_bt.Size = new System.Drawing.Size(75, 23);
			this.ReadSche_bt.TabIndex = 14;
			this.ReadSche_bt.Text = "Read Sched";
			this.ReadSche_bt.UseVisualStyleBackColor = true;
			this.ReadSche_bt.Click += new System.EventHandler(this.ReadSche_btClick);
			// 
			// DOW_cb
			// 
			this.DOW_cb.FormattingEnabled = true;
			this.DOW_cb.Items.AddRange(new object[] {
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday",
			"Sunday"});
			this.DOW_cb.Location = new System.Drawing.Point(6, 12);
			this.DOW_cb.Name = "DOW_cb";
			this.DOW_cb.Size = new System.Drawing.Size(114, 21);
			this.DOW_cb.TabIndex = 13;
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(6, 39);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(390, 175);
			this.dataGridView1.TabIndex = 0;
			this.dataGridView1.DoubleClick += new System.EventHandler(this.DataGridView1DoubleClick);
			// 
			// tabPage10
			// 
			this.tabPage10.Controls.Add(this.groupBox3);
			this.tabPage10.Location = new System.Drawing.Point(4, 22);
			this.tabPage10.Name = "tabPage10";
			this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage10.Size = new System.Drawing.Size(402, 279);
			this.tabPage10.TabIndex = 2;
			this.tabPage10.Text = "Status";
			this.tabPage10.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.StatusRead_bt);
			this.groupBox3.Controls.Add(this.NextEv_tb);
			this.groupBox3.Controls.Add(this.ProgTermTime_lb);
			this.groupBox3.Controls.Add(this.Satus_lb);
			this.groupBox3.Controls.Add(this.label8);
			this.groupBox3.Controls.Add(this.Mode_cb);
			this.groupBox3.Controls.Add(this.StatSet_bt);
			this.groupBox3.Controls.Add(this.label7);
			this.groupBox3.Controls.Add(this.Uart_log_cb);
			this.groupBox3.Controls.Add(this.ClockPer_nud);
			this.groupBox3.Controls.Add(this.label4);
			this.groupBox3.Controls.Add(this.label6);
			this.groupBox3.Controls.Add(this.ZB_log_cb);
			this.groupBox3.Controls.Add(this.Timeadj_nud);
			this.groupBox3.Controls.Add(this.label5);
			this.groupBox3.Location = new System.Drawing.Point(6, 6);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(390, 182);
			this.groupBox3.TabIndex = 1;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Status";
			// 
			// StatusRead_bt
			// 
			this.StatusRead_bt.Location = new System.Drawing.Point(299, 57);
			this.StatusRead_bt.Name = "StatusRead_bt";
			this.StatusRead_bt.Size = new System.Drawing.Size(75, 23);
			this.StatusRead_bt.TabIndex = 13;
			this.StatusRead_bt.Text = "Read";
			this.StatusRead_bt.UseVisualStyleBackColor = true;
			this.StatusRead_bt.Click += new System.EventHandler(this.StatusRead_bt_Click);
			// 
			// NextEv_tb
			// 
			this.NextEv_tb.Location = new System.Drawing.Point(106, 42);
			this.NextEv_tb.Name = "NextEv_tb";
			this.NextEv_tb.Size = new System.Drawing.Size(168, 20);
			this.NextEv_tb.TabIndex = 11;
			// 
			// ProgTermTime_lb
			// 
			this.ProgTermTime_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ProgTermTime_lb.Location = new System.Drawing.Point(112, 16);
			this.ProgTermTime_lb.Name = "ProgTermTime_lb";
			this.ProgTermTime_lb.Size = new System.Drawing.Size(140, 23);
			this.ProgTermTime_lb.TabIndex = 12;
			this.ProgTermTime_lb.Text = "0:0:0 1/1/1970";
			// 
			// Satus_lb
			// 
			this.Satus_lb.Location = new System.Drawing.Point(10, 42);
			this.Satus_lb.Name = "Satus_lb";
			this.Satus_lb.Size = new System.Drawing.Size(100, 23);
			this.Satus_lb.TabIndex = 0;
			this.Satus_lb.Text = "Next Event";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(10, 76);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(34, 13);
			this.label8.TabIndex = 5;
			this.label8.Text = "Mode";
			// 
			// Mode_cb
			// 
			this.Mode_cb.FormattingEnabled = true;
			this.Mode_cb.Items.AddRange(new object[] {
			"Manual",
			"Daily",
			"Once",
			"Out"});
			this.Mode_cb.Location = new System.Drawing.Point(13, 99);
			this.Mode_cb.Name = "Mode_cb";
			this.Mode_cb.Size = new System.Drawing.Size(57, 21);
			this.Mode_cb.TabIndex = 4;
			// 
			// StatSet_bt
			// 
			this.StatSet_bt.Location = new System.Drawing.Point(299, 97);
			this.StatSet_bt.Name = "StatSet_bt";
			this.StatSet_bt.Size = new System.Drawing.Size(75, 23);
			this.StatSet_bt.TabIndex = 10;
			this.StatSet_bt.Text = "Set";
			this.StatSet_bt.UseVisualStyleBackColor = true;
			this.StatSet_bt.Click += new System.EventHandler(this.StatSet_bt_Click);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(193, 130);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(103, 13);
			this.label7.TabIndex = 9;
			this.label7.Text = "Clock Display period";
			// 
			// Uart_log_cb
			// 
			this.Uart_log_cb.FormattingEnabled = true;
			this.Uart_log_cb.Items.AddRange(new object[] {
			"Verbose",
			"Debug",
			"Info",
			"Error"});
			this.Uart_log_cb.Location = new System.Drawing.Point(88, 99);
			this.Uart_log_cb.Name = "Uart_log_cb";
			this.Uart_log_cb.Size = new System.Drawing.Size(81, 21);
			this.Uart_log_cb.TabIndex = 2;
			// 
			// ClockPer_nud
			// 
			this.ClockPer_nud.Location = new System.Drawing.Point(196, 147);
			this.ClockPer_nud.Maximum = new decimal(new int[] {
			1000,
			0,
			0,
			0});
			this.ClockPer_nud.Name = "ClockPer_nud";
			this.ClockPer_nud.Size = new System.Drawing.Size(68, 20);
			this.ClockPer_nud.TabIndex = 8;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(90, 76);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(79, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "UART log level";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(193, 76);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 13);
			this.label6.TabIndex = 7;
			this.label6.Text = "Time Adj";
			// 
			// ZB_log_cb
			// 
			this.ZB_log_cb.FormattingEnabled = true;
			this.ZB_log_cb.Items.AddRange(new object[] {
			"Verbose",
			"Debug",
			"Info",
			"Error"});
			this.ZB_log_cb.Location = new System.Drawing.Point(88, 146);
			this.ZB_log_cb.Name = "ZB_log_cb";
			this.ZB_log_cb.Size = new System.Drawing.Size(81, 21);
			this.ZB_log_cb.TabIndex = 4;
			// 
			// Timeadj_nud
			// 
			this.Timeadj_nud.Location = new System.Drawing.Point(196, 99);
			this.Timeadj_nud.Maximum = new decimal(new int[] {
			125,
			0,
			0,
			0});
			this.Timeadj_nud.Name = "Timeadj_nud";
			this.Timeadj_nud.Size = new System.Drawing.Size(68, 20);
			this.Timeadj_nud.TabIndex = 6;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(86, 130);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(83, 13);
			this.label5.TabIndex = 5;
			this.label5.Text = "ZigBee log level";
			// 
			// tabPage11
			// 
			this.tabPage11.Controls.Add(this.ONOFFonce_cb);
			this.tabPage11.Controls.Add(this.ENonce_cb);
			this.tabPage11.Controls.Add(this.SetOnce_bt);
			this.tabPage11.Controls.Add(this.dateTimePicker1);
			this.tabPage11.Location = new System.Drawing.Point(4, 22);
			this.tabPage11.Name = "tabPage11";
			this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage11.Size = new System.Drawing.Size(402, 279);
			this.tabPage11.TabIndex = 3;
			this.tabPage11.Text = "Ev Calendar";
			this.tabPage11.UseVisualStyleBackColor = true;
			// 
			// ONOFFonce_cb
			// 
			this.ONOFFonce_cb.AutoSize = true;
			this.ONOFFonce_cb.Location = new System.Drawing.Point(273, 48);
			this.ONOFFonce_cb.Name = "ONOFFonce_cb";
			this.ONOFFonce_cb.Size = new System.Drawing.Size(51, 17);
			this.ONOFFonce_cb.TabIndex = 3;
			this.ONOFFonce_cb.Text = "State";
			this.ONOFFonce_cb.UseVisualStyleBackColor = true;
			// 
			// ENonce_cb
			// 
			this.ENonce_cb.AutoSize = true;
			this.ENonce_cb.Location = new System.Drawing.Point(225, 48);
			this.ENonce_cb.Name = "ENonce_cb";
			this.ENonce_cb.Size = new System.Drawing.Size(41, 17);
			this.ENonce_cb.TabIndex = 2;
			this.ENonce_cb.Text = "EN";
			this.ENonce_cb.UseVisualStyleBackColor = true;
			// 
			// SetOnce_bt
			// 
			this.SetOnce_bt.Location = new System.Drawing.Point(34, 87);
			this.SetOnce_bt.Name = "SetOnce_bt";
			this.SetOnce_bt.Size = new System.Drawing.Size(75, 23);
			this.SetOnce_bt.TabIndex = 1;
			this.SetOnce_bt.Text = "Set";
			this.SetOnce_bt.UseVisualStyleBackColor = true;
			this.SetOnce_bt.Click += new System.EventHandler(this.SetOnce_bt_Click);
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.AllowDrop = true;
			this.dateTimePicker1.CustomFormat = "\"dd/MM/yy  HH:mm\"";
			this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker1.Location = new System.Drawing.Point(36, 48);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.ShowUpDown = true;
			this.dateTimePicker1.Size = new System.Drawing.Size(182, 20);
			this.dateTimePicker1.TabIndex = 0;
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(12, 323);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(406, 127);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "";
			// 
			// timer1
			// 
			this.timer1.Tick += new System.EventHandler(this.timer1tick);
			// 
			// today_tb
			// 
			this.today_tb.Location = new System.Drawing.Point(126, 10);
			this.today_tb.Name = "today_tb";
			this.today_tb.Size = new System.Drawing.Size(75, 23);
			this.today_tb.TabIndex = 18;
			this.today_tb.Text = "Today";
			this.today_tb.UseVisualStyleBackColor = true;
			this.today_tb.Click += new System.EventHandler(this.Today_tbClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(434, 462);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.tabControl1);
			this.Name = "MainForm";
			this.Text = "HeatersGUI";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.OooHurs_nud)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.tabPage10.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.ClockPer_nud)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.Timeadj_nud)).EndInit();
			this.tabPage11.ResumeLayout(false);
			this.tabPage11.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
			this.ResumeLayout(false);

		}

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Button SetOnce_bt;
        private System.Windows.Forms.ComboBox Copyto_cb;
        private System.Windows.Forms.Button CopyDay_bt;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox ONOFFonce_cb;
        private System.Windows.Forms.CheckBox ENonce_cb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown ClockPer_nud;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown Timeadj_nud;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ZB_log_cb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Uart_log_cb;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button StatSet_bt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Mode_cb;
        private System.Windows.Forms.Button StatusRead_bt;
        private System.Windows.Forms.TextBox NextEv_tb;
        private System.Windows.Forms.Label ProgTermTime_lb;
        private System.Windows.Forms.Button ManOFF_bt;
        private System.Windows.Forms.Button ManON_bt;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.ComboBox DOW_cb;
        private System.Windows.Forms.Button ReadSche_bt;
        private System.Windows.Forms.Button SetDayAl_bt;
        private System.Windows.Forms.Button Set_bt;
        private System.Windows.Forms.RadioButton Out_rb;
        private System.Windows.Forms.RadioButton Once_rb;
        private System.Windows.Forms.RadioButton Daily_rb;
        private System.Windows.Forms.RadioButton Man_rb;
        private System.Windows.Forms.Label HState_lb;
        private System.Windows.Forms.Label RemTime_lb;
        private System.Windows.Forms.Button now_bt;
        private System.Windows.Forms.TextBox timeset_tb;
        private System.Windows.Forms.Button today_tb;
        
        //private System.Windows.Forms.ComboBox Copyto_cb;
        //private System.Windows.Forms.Button CopyDay_bt;
	}
}

﻿/*
 * Created by SharpDevelop.
 * User: tasselli
 * Date: 28/10/2017
 * Time: 17:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace HeatersGUI
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.TabControl tabControl2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.DataGridViewTextBoxColumn Time;
		private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
		private System.Windows.Forms.DataGridViewCheckBoxColumn Column2;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.TabPage tabPage6;
		private System.Windows.Forms.TabPage tabPage7;
		private System.Windows.Forms.TabPage tabPage8;
		private System.Windows.Forms.TabPage tabPage9;
		private System.Windows.Forms.ComboBox Uartbaud_cb;
		private System.Windows.Forms.Button Connect_bt;
		private System.Windows.Forms.ComboBox Com_cb;
		private System.IO.Ports.SerialPort Sport;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Label time_lb;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TabPage tabPage10;
		private System.Windows.Forms.Label Satus_lb;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.NumericUpDown evnum_nud;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.CheckBox onoff_cb;
		private System.Windows.Forms.CheckBox en_cb;
		private System.Windows.Forms.NumericUpDown min_nud;
		private System.Windows.Forms.NumericUpDown hh_nud;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Day_cb = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.evnum_nud = new System.Windows.Forms.NumericUpDown();
            this.button3 = new System.Windows.Forms.Button();
            this.onoff_cb = new System.Windows.Forms.CheckBox();
            this.en_cb = new System.Windows.Forms.CheckBox();
            this.min_nud = new System.Windows.Forms.NumericUpDown();
            this.hh_nud = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.time_lb = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Uartbaud_cb = new System.Windows.Forms.ComboBox();
            this.Connect_bt = new System.Windows.Forms.Button();
            this.Com_cb = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.StatSet_bt = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.ClockPer_nud = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.Timeadj_nud = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.ZB_log_cb = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Uart_log_cb = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Mode_cb = new System.Windows.Forms.ComboBox();
            this.Satus_lb = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.ONOFFonce_cb = new System.Windows.Forms.CheckBox();
            this.ENonce_cb = new System.Windows.Forms.CheckBox();
            this.SetOnce_bt = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Sport = new System.IO.Ports.SerialPort(this.components);
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.NextEv_tb = new System.Windows.Forms.TextBox();
            this.ProgTermTime_lb = new System.Windows.Forms.Label();
            this.StatusRead_bt = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.evnum_nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hh_nud)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClockPer_nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Timeadj_nud)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(410, 307);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.Uartbaud_cb);
            this.tabPage1.Controls.Add(this.Connect_bt);
            this.tabPage1.Controls.Add(this.Com_cb);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(402, 281);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Setup";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Day_cb);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.evnum_nud);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.onoff_cb);
            this.groupBox2.Controls.Add(this.en_cb);
            this.groupBox2.Controls.Add(this.min_nud);
            this.groupBox2.Controls.Add(this.hh_nud);
            this.groupBox2.Location = new System.Drawing.Point(3, 139);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(385, 65);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // Day_cb
            // 
            this.Day_cb.FormattingEnabled = true;
            this.Day_cb.Items.AddRange(new object[] {
            "Monday",
            "Tuesday",
            "Wednesday"});
            this.Day_cb.Location = new System.Drawing.Point(187, 8);
            this.Day_cb.Name = "Day_cb";
            this.Day_cb.Size = new System.Drawing.Size(89, 21);
            this.Day_cb.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(111, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 23);
            this.label3.TabIndex = 11;
            this.label3.Text = "Ev";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(139, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 23);
            this.label2.TabIndex = 10;
            this.label2.Text = "m";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(75, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 23);
            this.label1.TabIndex = 9;
            this.label1.Text = "h";
            // 
            // evnum_nud
            // 
            this.evnum_nud.Location = new System.Drawing.Point(139, 10);
            this.evnum_nud.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.evnum_nud.Name = "evnum_nud";
            this.evnum_nud.Size = new System.Drawing.Size(34, 20);
            this.evnum_nud.TabIndex = 8;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 36);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "Set Day Ev";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.SetDayEv_bt);
            // 
            // onoff_cb
            // 
            this.onoff_cb.Location = new System.Drawing.Point(244, 30);
            this.onoff_cb.Name = "onoff_cb";
            this.onoff_cb.Size = new System.Drawing.Size(104, 24);
            this.onoff_cb.TabIndex = 6;
            this.onoff_cb.Text = "ON";
            this.onoff_cb.UseVisualStyleBackColor = true;
            // 
            // en_cb
            // 
            this.en_cb.Location = new System.Drawing.Point(204, 30);
            this.en_cb.Name = "en_cb";
            this.en_cb.Size = new System.Drawing.Size(104, 24);
            this.en_cb.TabIndex = 5;
            this.en_cb.Text = "EN";
            this.en_cb.UseVisualStyleBackColor = true;
            // 
            // min_nud
            // 
            this.min_nud.Increment = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.min_nud.Location = new System.Drawing.Point(155, 36);
            this.min_nud.Maximum = new decimal(new int[] {
            45,
            0,
            0,
            0});
            this.min_nud.Name = "min_nud";
            this.min_nud.Size = new System.Drawing.Size(43, 20);
            this.min_nud.TabIndex = 4;
            // 
            // hh_nud
            // 
            this.hh_nud.Location = new System.Drawing.Point(90, 36);
            this.hh_nud.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.hh_nud.Name = "hh_nud";
            this.hh_nud.Size = new System.Drawing.Size(43, 20);
            this.hh_nud.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.time_lb);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(6, 60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(390, 215);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Commands";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(7, 50);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Read Status";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.RdStatus_bt);
            // 
            // time_lb
            // 
            this.time_lb.Location = new System.Drawing.Point(95, 25);
            this.time_lb.Name = "time_lb";
            this.time_lb.Size = new System.Drawing.Size(100, 23);
            this.time_lb.TabIndex = 1;
            this.time_lb.Text = "label1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Set Time";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.SetTime_bt);
            // 
            // Uartbaud_cb
            // 
            this.Uartbaud_cb.FormattingEnabled = true;
            this.Uartbaud_cb.Items.AddRange(new object[] {
            "115200",
            "38400",
            "9600"});
            this.Uartbaud_cb.Location = new System.Drawing.Point(6, 33);
            this.Uartbaud_cb.Name = "Uartbaud_cb";
            this.Uartbaud_cb.Size = new System.Drawing.Size(88, 21);
            this.Uartbaud_cb.TabIndex = 2;
            // 
            // Connect_bt
            // 
            this.Connect_bt.Location = new System.Drawing.Point(101, 6);
            this.Connect_bt.Name = "Connect_bt";
            this.Connect_bt.Size = new System.Drawing.Size(75, 23);
            this.Connect_bt.TabIndex = 1;
            this.Connect_bt.Text = "Connect";
            this.Connect_bt.UseVisualStyleBackColor = true;
            this.Connect_bt.Click += new System.EventHandler(this.Connect_btClick);
            // 
            // Com_cb
            // 
            this.Com_cb.FormattingEnabled = true;
            this.Com_cb.Location = new System.Drawing.Point(6, 6);
            this.Com_cb.Name = "Com_cb";
            this.Com_cb.Size = new System.Drawing.Size(88, 21);
            this.Com_cb.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(402, 281);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Scheduler";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Location = new System.Drawing.Point(6, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(393, 272);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(385, 246);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Monday";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Time,
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(373, 234);
            this.dataGridView1.TabIndex = 0;
            // 
            // Time
            // 
            this.Time.HeaderText = "Time";
            this.Time.Name = "Time";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Enable";
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Time";
            this.Column2.HeaderText = "State";
            this.Column2.Name = "Column2";
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(385, 246);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Tuesday";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(385, 246);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Wednesday";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(385, 246);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "Thursday";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(385, 246);
            this.tabPage7.TabIndex = 4;
            this.tabPage7.Text = "Friday";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(385, 246);
            this.tabPage8.TabIndex = 5;
            this.tabPage8.Text = "Saturday";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(385, 246);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "Sunday";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox3);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(402, 281);
            this.tabPage10.TabIndex = 2;
            this.tabPage10.Text = "Status";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // StatSet_bt
            // 
            this.StatSet_bt.Location = new System.Drawing.Point(299, 97);
            this.StatSet_bt.Name = "StatSet_bt";
            this.StatSet_bt.Size = new System.Drawing.Size(75, 23);
            this.StatSet_bt.TabIndex = 10;
            this.StatSet_bt.Text = "Set";
            this.StatSet_bt.UseVisualStyleBackColor = true;
            this.StatSet_bt.Click += new System.EventHandler(this.StatSet_bt_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(193, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Clock Display period";
            // 
            // ClockPer_nud
            // 
            this.ClockPer_nud.Location = new System.Drawing.Point(196, 147);
            this.ClockPer_nud.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ClockPer_nud.Name = "ClockPer_nud";
            this.ClockPer_nud.Size = new System.Drawing.Size(68, 20);
            this.ClockPer_nud.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(193, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Time Adj";
            // 
            // Timeadj_nud
            // 
            this.Timeadj_nud.Location = new System.Drawing.Point(196, 99);
            this.Timeadj_nud.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.Timeadj_nud.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.Timeadj_nud.Name = "Timeadj_nud";
            this.Timeadj_nud.Size = new System.Drawing.Size(68, 20);
            this.Timeadj_nud.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(86, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "ZigBee log level";
            // 
            // ZB_log_cb
            // 
            this.ZB_log_cb.FormattingEnabled = true;
            this.ZB_log_cb.Items.AddRange(new object[] {
            "Verbose",
            "Debug",
            "Info",
            "Error"});
            this.ZB_log_cb.Location = new System.Drawing.Point(88, 146);
            this.ZB_log_cb.Name = "ZB_log_cb";
            this.ZB_log_cb.Size = new System.Drawing.Size(81, 21);
            this.ZB_log_cb.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "UART log level";
            // 
            // Uart_log_cb
            // 
            this.Uart_log_cb.FormattingEnabled = true;
            this.Uart_log_cb.Items.AddRange(new object[] {
            "Verbose",
            "Debug",
            "Info",
            "Error"});
            this.Uart_log_cb.Location = new System.Drawing.Point(88, 99);
            this.Uart_log_cb.Name = "Uart_log_cb";
            this.Uart_log_cb.Size = new System.Drawing.Size(81, 21);
            this.Uart_log_cb.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.StatusRead_bt);
            this.groupBox3.Controls.Add(this.NextEv_tb);
            this.groupBox3.Controls.Add(this.ProgTermTime_lb);
            this.groupBox3.Controls.Add(this.Satus_lb);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.Mode_cb);
            this.groupBox3.Controls.Add(this.StatSet_bt);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.Uart_log_cb);
            this.groupBox3.Controls.Add(this.ClockPer_nud);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.ZB_log_cb);
            this.groupBox3.Controls.Add(this.Timeadj_nud);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(390, 182);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Status";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Mode";
            // 
            // Mode_cb
            // 
            this.Mode_cb.FormattingEnabled = true;
            this.Mode_cb.Items.AddRange(new object[] {
            "Manual",
            "Daily",
            "Once",
            "Out"});
            this.Mode_cb.Location = new System.Drawing.Point(13, 99);
            this.Mode_cb.Name = "Mode_cb";
            this.Mode_cb.Size = new System.Drawing.Size(57, 21);
            this.Mode_cb.TabIndex = 4;
            // 
            // Satus_lb
            // 
            this.Satus_lb.Location = new System.Drawing.Point(10, 42);
            this.Satus_lb.Name = "Satus_lb";
            this.Satus_lb.Size = new System.Drawing.Size(100, 23);
            this.Satus_lb.TabIndex = 0;
            this.Satus_lb.Text = "Next Event";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.ONOFFonce_cb);
            this.tabPage11.Controls.Add(this.ENonce_cb);
            this.tabPage11.Controls.Add(this.SetOnce_bt);
            this.tabPage11.Controls.Add(this.dateTimePicker1);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(402, 281);
            this.tabPage11.TabIndex = 3;
            this.tabPage11.Text = "Ev Calendar";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // ONOFFonce_cb
            // 
            this.ONOFFonce_cb.AutoSize = true;
            this.ONOFFonce_cb.Location = new System.Drawing.Point(273, 48);
            this.ONOFFonce_cb.Name = "ONOFFonce_cb";
            this.ONOFFonce_cb.Size = new System.Drawing.Size(51, 17);
            this.ONOFFonce_cb.TabIndex = 3;
            this.ONOFFonce_cb.Text = "State";
            this.ONOFFonce_cb.UseVisualStyleBackColor = true;
            // 
            // ENonce_cb
            // 
            this.ENonce_cb.AutoSize = true;
            this.ENonce_cb.Location = new System.Drawing.Point(225, 48);
            this.ENonce_cb.Name = "ENonce_cb";
            this.ENonce_cb.Size = new System.Drawing.Size(41, 17);
            this.ENonce_cb.TabIndex = 2;
            this.ENonce_cb.Text = "EN";
            this.ENonce_cb.UseVisualStyleBackColor = true;
            // 
            // SetOnce_bt
            // 
            this.SetOnce_bt.Location = new System.Drawing.Point(34, 87);
            this.SetOnce_bt.Name = "SetOnce_bt";
            this.SetOnce_bt.Size = new System.Drawing.Size(75, 23);
            this.SetOnce_bt.TabIndex = 1;
            this.SetOnce_bt.Text = "Set";
            this.SetOnce_bt.UseVisualStyleBackColor = true;
            this.SetOnce_bt.Click += new System.EventHandler(this.SetOnce_bt_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.AllowDrop = true;
            this.dateTimePicker1.CustomFormat = "\"dd/MM/yy  HH:mm\"";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(36, 48);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(182, 20);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 323);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(406, 127);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1tick);
            // 
            // NextEv_tb
            // 
            this.NextEv_tb.Location = new System.Drawing.Point(106, 42);
            this.NextEv_tb.Name = "NextEv_tb";
            this.NextEv_tb.Size = new System.Drawing.Size(168, 20);
            this.NextEv_tb.TabIndex = 11;
            // 
            // ProgTermTime_lb
            // 
            this.ProgTermTime_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProgTermTime_lb.Location = new System.Drawing.Point(112, 16);
            this.ProgTermTime_lb.Name = "ProgTermTime_lb";
            this.ProgTermTime_lb.Size = new System.Drawing.Size(140, 23);
            this.ProgTermTime_lb.TabIndex = 12;
            this.ProgTermTime_lb.Text = "0:0:0 1/1/1970";
            // 
            // StatusRead_bt
            // 
            this.StatusRead_bt.Location = new System.Drawing.Point(299, 57);
            this.StatusRead_bt.Name = "StatusRead_bt";
            this.StatusRead_bt.Size = new System.Drawing.Size(75, 23);
            this.StatusRead_bt.TabIndex = 13;
            this.StatusRead_bt.Text = "Read";
            this.StatusRead_bt.UseVisualStyleBackColor = true;
            this.StatusRead_bt.Click += new System.EventHandler(this.StatusRead_bt_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 462);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainForm";
            this.Text = "HeatersGUI";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.evnum_nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hh_nud)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ClockPer_nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Timeadj_nud)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.ResumeLayout(false);

		}

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox Day_cb;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Button SetOnce_bt;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox ONOFFonce_cb;
        private System.Windows.Forms.CheckBox ENonce_cb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown ClockPer_nud;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown Timeadj_nud;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ZB_log_cb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Uart_log_cb;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button StatSet_bt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Mode_cb;
        private System.Windows.Forms.Button StatusRead_bt;
        private System.Windows.Forms.TextBox NextEv_tb;
        private System.Windows.Forms.Label ProgTermTime_lb;
	}
}

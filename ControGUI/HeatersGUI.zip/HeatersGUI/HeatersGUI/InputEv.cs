﻿/*
 * Created by SharpDevelop.
 * User: tasselli
 * Date: 11/11/2017
 * Time: 16:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using HeatersScheduler;
namespace HeatersGUI
{
	/// <summary>
	/// Description of Form1.
	/// </summary>
	public partial class Form1 : Form
	{
		public Form1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		public DaySched ds;
		void Apply_btClick(object sender, EventArgs e)
		{
			String time=HH_nud.Value.ToString()+':'+MM_nud.Value.ToString();
			ds=new DaySched(0,time,en_cb.Checked,st_cb.Checked);
			this.Close();
		}
	}
}
